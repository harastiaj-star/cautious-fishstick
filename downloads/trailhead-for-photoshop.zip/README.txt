Trailhead for Photoshop

Needs Photoshop 2023 (version 24.2) or newer. Filters, textures and color pulling need Photoshop 2024 or newer.

Install
1. Quit Photoshop.
2. Double-click Trailhead.ccx. The Creative Cloud app opens.
3. Creative Cloud warns that the plugin isn't verified by Adobe yet. Click Install locally, then OK.
4. Open Photoshop and choose Plugins > Trailhead.

If Creative Cloud says "Couldn't install plugin"
Some versions of Photoshop 2026 refuse plugins installed this way. Load it with Adobe's free UXP Developer Tool instead:
1. Install UXP Developer Tool from the Creative Cloud app (Apps, then search for it).
2. Unzip Trailhead.ccx like a normal zip file into a folder you'll keep.
3. In UXP Developer Tool, click Add Plugin and choose manifest.json in that folder.
4. Click the ... next to Trailhead and choose Load.

To remove it, find Trailhead in the Creative Cloud app's plugin list and choose Uninstall.
